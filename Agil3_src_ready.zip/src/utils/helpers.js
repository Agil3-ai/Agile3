// TODO: Add implementation for helpers.js
