// TODO: Add implementation for formatDate.js
