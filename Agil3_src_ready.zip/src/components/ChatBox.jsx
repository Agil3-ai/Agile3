// TODO: Add implementation for ChatBox.jsx
