// TODO: Add implementation for simplywallstAPI.js
