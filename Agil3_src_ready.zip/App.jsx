import React from "react";
import Home from "./pages/Home";
import { ChatProvider } from "./context/ChatContext";
import "./i18n/i18n";

const App = () => {
  return (
    <ChatProvider>
      <Home />
    </ChatProvider>
  );
};

export default App;